from DobotDemo import DobotDemo

if __name__ == '__main__':
    dobot = DobotDemo("192.168.5.1")
    dobot.start()
